package io.github.wujun728.db;

import java.sql.Connection;
import java.sql.SQLException;

import com.mchange.v2.c3p0.ComboPooledDataSource;

/**
 * c3p0工具 2018年9月11日 created by Mao
 */
public class C3p0Util {
	private static ComboPooledDataSource dataSource = new ComboPooledDataSource();

	/** 获取数据源 **/
	public static ComboPooledDataSource getDataSource() {
		return dataSource;
	}

	/** 获取数据库连接 **/
	public static Connection getConn() {
		try {
			return dataSource.getConnection();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
}
