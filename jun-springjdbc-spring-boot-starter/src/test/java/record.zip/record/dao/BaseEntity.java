package record.dao;

/**
 * BaseEntity接口
 * 包含强类型和弱类型实体
 * @author sxjun
 * 2016-2-1
 */
public interface BaseEntity {

}
